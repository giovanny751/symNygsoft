<?php
class MiExcepción extends Exception {}
?>
