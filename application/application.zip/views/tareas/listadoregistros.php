<div class="widgetTitle" >
    <h5>
        <i class="glyphicon glyphicon-ok"></i>REGISTROS
    </h5>
</div>
<div class='well'>
    <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
            <div class="form-group">
                <label for="cedula">Plan</label><input type="text" name="cedula" id="cedula" class="form-control">
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
            <div class="form-group">
                <label for="nombre">Actividad</label><input type="text" name="nombre" id="nombre" class="form-control">
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
            <div class="form-group">
                <label for="apellido">Tarea</label><input type="text" name="apellido" id="apellido" class="form-control">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
            <div class="form-group">
                <label for="estado">Empleado</label><input type="text" name="estado" id="estado" class="form-control">
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4" style="text-align: center">
            <div class="form-group">
                <label>&nbsp;</label><button type="button" class="btn btn-success">Consultar</button>
            </div>
        </div>

    </div>
    <hr>
    <div class="row">
        <table class="table table-bordered table-hover">
            <thead>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Versión</th>
            <th>Categoría</th>
            <th>Tarea</th>
            <th>Responsable</th>
            <th>Tamaño</th>
            <th>Fecha</th>
            <th>Opciones</th>
            </thead>
            <tbody>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
            </tbody>
        </table>
    </div>    
</div>    