<div class="row">
    <div class="col-md-12">
        <div class="portlet box green">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-gift"></i>Prestamo Empleados
                </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse">
                    </a>
                </div>
            </div>
            <div class="portlet-body form">
                <div class="form-body">
                    <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="nit" class="control-label col-md-3">Empleado</label>
                                    <div class="col-md-9">
                                        <select name="empleado" class="form-control"> 
                                            <option value=""></option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="razonsocial" class="control-label col-md-3">Fecha prestamo</label>
                                    <div class="col-md-9">
                                        <input value="" name="fechaPrestamo" id="fechaPrestamo" class="form-control fecha"/>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>