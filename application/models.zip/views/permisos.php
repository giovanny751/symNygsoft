<div class="row">
    <div class="col-md-12 page-404">
        <div class="number">
            Error
        </div>
        <div class="details">
            <h3>PERMISOS</h3>
            <!--<h3>El Usuario no cuenta con los permisos para acceder este modulo.</h3>-->
            <p>
                     El Usuario no cuenta con los permisos.<br/>
                     para acceder este modulo.<br/>
                    <a href="<?php echo base_url("index.php/presentacion/principal") ?>">
                    Inicio </a>
            </p>                
        </div>
    </div>
</div>