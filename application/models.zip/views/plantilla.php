<?php 
$this->load->view('include/head');
echo $contenido;;
$this->load->view('include/footer');
?>