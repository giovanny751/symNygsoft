
Bienvenido al sistema de evaluación de (nombre de la empresa)

"En este momento usted realizara una(s) prueba(s) sencilla(s), la(s) cual(es) le fue(ron) asignada(s)
con anterioridad, está(n) compuesta por una serie de preguntas de diversas áreas y temáticas del 
conocimiento. Recuerde que es importante que usted diligencia esta prueba por completo, 
debido a que por este medio la compañía conoce a sus empleados y como se sienten dentro de la empresa. 