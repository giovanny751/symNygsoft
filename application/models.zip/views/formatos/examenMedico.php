<table style="width: 100%;border: 1px solid black">
    <tr>
        <td>Examen de:</td>
        <td colspan="3"></td>
    </tr>
    <tr>
        <td>Fecha</td>
        <td></td>
        <td>Doctor</td>
        <td></td>
    </tr>
    <tr>
        <td>Dirección</td>
        <td></td>
        <td>Teléfono</td>
        <td></td>
    </tr>
    <tr>
        <td>Tipo identificación</td>
        <td></td>
        <td>Identificación</td>
        <td></td>
    </tr>
    <tr>
        <td>Cargo a desempeñar</td>
        <td></td>
        <td>Fecha de ingreso</td>
        <td></td>
    </tr>
    <tr>
        <td style="text-align:center;background-color: #CCCCCC " colspan="4">Datos Suministrados por el Coordinador de SST</td>
    </tr>
    <tr>
        <td  colspan="4" >Actividad a desempeñar</td>
    </tr>
    <tr>
        <td  colspan="4" style="text-align:center">NOTA IMPORTANTE: SIN LOS RESULTADOS DE LOS EXÁMENES QUE A CONTINUACIÓN SEÑALADOS CON UNA X POR FAVOR NO VALORAR AL PACIENTE, YA QUE SON REQUERIDOS PARA EL CARGO</td>
    </tr>
    <tr>
        <td style="height: 130px" colspan="2"></td>
        <td style="height: 130px" colspan="2"></td>
    </tr>
    <tr>
        <td colspan="2">Coordinador SST</td>
        <td colspan="2">Recibido (Trabajador)</td>
    </tr>
</table>