<div class="widgetTitle" >
    <h5>
        <i class="glyphicon glyphicon-ok"></i>AGREGAR REGUSTRO
    </h5>
</div>
<div class='well'>
    <div class="row">
        <div class="col-lg-offset-3 col-md-offset-3 col-sm-offset-3 col-xs-offset-3 col-lg-6 col-md-6 col-sm-6 col-xs-6">
            <label class="">Plan</label>
            <select name="plan" id="plan" class="form-control">
                <option value="">::Seleccionar::</option>
            </select>
        </div>
    </div>    
    <div class="row">
        <div class="col-lg-offset-3 col-md-offset-3 col-sm-offset-3 col-xs-offset-3 col-lg-6 col-md-6 col-sm-6 col-xs-6">
            <label class="">Tarea</label>
            <select name="" id="tarea" name="tarea" class="form-control">
                <option value="">::Seleccionar::</option>
            </select>
        </div>
    </div>    
    <div class="row">
        <div class="col-lg-offset-3 col-md-offset-3 col-sm-offset-3 col-xs-offset-3 col-lg-6 col-md-6 col-sm-6 col-xs-6">
            <label class="">Carpeta</label>
            <select name="carpeta" id="carpeta" class="form-control">
                <option value="">::Seleccionar::</option>
            </select>
        </div>
    </div>    
    <div class="row">
        <div class="col-lg-offset-3 col-md-offset-3 col-sm-offset-3 col-xs-offset-3 col-lg-6 col-md-6 col-sm-6 col-xs-6">
            <label class="">Versión</label>
            <input type="" name="version" id="version" class="form-control">
        </div>
    </div>    
    <div class="row">
        <div class="col-lg-offset-3 col-md-offset-3 col-sm-offset-3 col-xs-offset-3 col-lg-6 col-md-6 col-sm-6 col-xs-6">
            <label class="">Descripción</label>
            <input type="" name="descripcion" id="descripcion" class="form-control">
        </div>
    </div>    
    <div class="row">
        <div class="col-lg-offset-3 col-md-offset-3 col-sm-offset-3 col-xs-offset-3 col-lg-6 col-md-6 col-sm-6 col-xs-6">
            <label class="">Archivo adjunto</label>
            <input type="file" name="archivo" id="archivo"  class="form-control">
        </div>
    </div>    
    <div class="row">
        <center>
            <button type="button" id="guardar" class="btn btn-success">Guardar</button>
        </center>
    </div>    
</div>